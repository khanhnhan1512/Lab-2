# Module information:
# - This folder contains the Python source codes used for generating, or downloading datasets which used for this project.
# File: __init__.py
# Functionality: Making ```data``` become a Python module