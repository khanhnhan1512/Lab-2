# Module information:
# - This folder contains the Python source codes used for making visualization functional in data exploration stage.
# File: __init__.py
# Functionality: Making ```visualizations``` become a Python module